# Single Session Enforcement (first login wins) — Liferay DXP 2025.Q1

A new login is **rejected** while the same user still has a live session in another browser or device. This works for form login and for SSO (SAML/OIDC), and it is safe across a cluster.

> 2025.Q1 uses `javax.servlet`. For 2025.Q3+ (Jakarta EE), change the `javax.servlet.*` imports to `jakarta.servlet.*`.

## Modules

| Module | Contents |
|---|---|
| `single-session-api` | Generated Service Builder API (`ActiveSession`, `ActiveSessionLocalService`) |
| `single-session-service` | `service.xml` and `ActiveSessionLocalServiceImpl` (registry primitives) |
| `single-session-web` | Config, `SingleSessionManager` (policy), login post-action, servlet filter, session-destroy action |

## Build and deploy

```bash
# Copy modules/single-session into your Liferay Workspace's modules/ folder, then:
blade gw :modules:single-session:single-session-service:buildService
blade gw :modules:single-session:single-session-api:deploy \
         :modules:single-session:single-session-service:deploy \
         :modules:single-session:single-session-web:deploy
# Copy configs/common/osgi/configs/*.config to $LIFERAY_HOME/osgi/configs/
```

Prerequisites:
1. Create a **public** page at `rejectedRedirectURL` (default `/web/guest/session-in-use`) with text like "You're already signed in on another browser or device. Sign out there, or try again after N minutes." It must not require login. If it does, SSO will log the user in again, they'll be rejected again, and the browser will loop.
2. Leave `auth.simultaneous.logins` at its default (`true`), or keep `live.users.enabled=false`. If the built-in feature is also active, it kills the *first* session while this module rejects the *second*, and the user ends up with no session at all.
3. Use sticky sessions on the load balancer (standard for Liferay).

## Registry table `AcmeSS_ActiveSession`

| Column | Purpose |
|---|---|
| `userId` (PK) | **Uniqueness = the lock.** A second concurrent INSERT fails on the PK. |
| `sessionId` | Owning HTTP session (Tomcat jvmRoute suffix stripped) |
| `nodeId` | Owning cluster node (diagnostics) |
| `expirationDate` | Lease = last heartbeat + session timeout + grace |
| `lastHeartbeatDate`, `createDate`, `companyId` | Audit |
| `mvccVersion` | Optimistic lock for take-over and heartbeat updates |

Entity cache is disabled so every node reads the database, which is the only shared state.

## Flow

### A. First login (browser A)
1. The user authenticates at the IdP. Liferay's auto-login (SAML/OIDC) establishes the session, and MainServlet fires `login.events.post`.
2. `SingleSessionLoginPostAction` calls `SingleSessionManager.claim()`.
3. Exempt role? Cache `EXEMPT` in the session and allow.
4. `ActiveSessionLocalService.claim()` runs in a REQUIRES_NEW transaction. No row exists, so it INSERTs `(userId, sessionA, lease)`. Result: **CLAIMED**.
5. The session attributes `OWNER_USER_ID` and `LAST_HEARTBEAT` are set. The page renders normally.

### B. Ongoing activity (browser A)
6. On each request, `SingleSessionFilter` sees `USER_ID` in the session and calls `verify()`.
7. If less than `heartbeatIntervalSeconds` has passed since the last heartbeat, it allows the request with no DB access.
8. Otherwise it calls `heartbeat()`, which UPDATEs `expirationDate` if A still owns the row. Liferay's session auto-extend ping keeps this running while a tab is open.

### C. Second login (browser B) is rejected
9. B authenticates at the IdP (its own IdP session), and `login.events.post` fires.
10. `claim()` finds A's row: a different session with a lease still in the future. It returns `false`. Result: **REJECTED**.
11. `reject()` invalidates B's Liferay session, sends a 302 to `rejectedRedirectURL`, and calls `flushBuffer()` to commit the response.
12. B lands on the public "session in use" page as a guest. A is unaffected.
13. If B opens a protected page, SSO logs it in silently again and step 10 rejects it again. No loop, because the rejected page is public.

### D. Race: A and B log in at the same moment on different nodes
14. Both find no row and both INSERT. The PK lets exactly one commit. The loser gets an exception, retries once, re-reads the winner's row, and is rejected.

### E. Lock release
15. **Logout or session timeout:** `servlet.session.destroy.events` triggers `SingleSessionDestroyAction`, which calls `release()`. That DELETEs the row only if the destroyed session is the owner, so a rejected session can never unlock someone else.
16. **Browser closed without logout:** the server session lives until it times out, then step 15 runs. Until then, new logins are rejected. This is the inherent trade-off of first-login-wins.
17. **Node crash (no destroy event):** the row stays until `expirationDate`, and then the next `claim()` takes it over (UPDATE with an MVCC check).
18. **Helpdesk:** `scripts/force-release.groovy` frees the lock immediately.

### F. Failure handling
- Registry DB down at login: `failOpen=false` (default) rejects; `true` allows the login untracked and retries after one heartbeat interval.
- Registry DB down during heartbeat: established owners are **never** kicked.
- Sessions that existed before deployment: the first filter pass claims them, or rejects them if another session already owns the user.

## Tuning
- `gracePeriodSeconds` must be greater than `heartbeatIntervalSeconds` plus the maximum clock skew between nodes, or a live owner could be taken over.
- The lockout window after a closed browser is roughly `session.timeout` + grace. Lower `session.timeout` (and keep `session.timeout.auto.extend=true`) to shrink it.

## Verify on your build (test cases)
1. Log in on A, then on B. B lands on the rejected page; A keeps working. Check the INFO log line.
2. Log out on A, then log in on B. B succeeds.
3. Close A without logging out, then log in on B. B is rejected until the timeout plus grace; after force-release it succeeds.
4. Cluster: A on node1, B on node2. B is rejected.
5. Start two logins at the same moment (for example with a JMeter barrier). Exactly one row and one surviving session.
6. Kill node1 while A is logged in. B succeeds after the lease expires.
7. Check the logs for the B login request. A harmless "response already committed" warning may appear because Liferay keeps processing that request after the 302 is committed.
