package com.acme.singlesession.web.configuration;

import aQute.bnd.annotation.metatype.Meta;

import com.liferay.portal.configuration.metatype.annotations.ExtendedObjectClassDefinition;

/**
 * Control Panel > System Settings > SSO > Single Session Enforcement.
 */
@ExtendedObjectClassDefinition(
	category = "sso",
	scope = ExtendedObjectClassDefinition.Scope.SYSTEM
)
@Meta.OCD(
	id = "com.acme.singlesession.web.configuration.SingleSessionConfiguration",
	name = "Single Session Enforcement"
)
public interface SingleSessionConfiguration {

	@Meta.AD(
		deflt = "true", description = "Reject a new login while another live session exists for the same user.",
		name = "Enabled", required = false
	)
	public boolean enabled();

	@Meta.AD(
		deflt = "/web/guest/session-in-use",
		description = "MUST be a public page that does not trigger SSO, otherwise you get a redirect loop.",
		name = "Rejected redirect URL", required = false
	)
	public String rejectedRedirectURL();

	@Meta.AD(
		deflt = "60",
		description = "Minimum seconds between lease renewals (DB writes) per session.",
		name = "Heartbeat interval (seconds)", required = false
	)
	public int heartbeatIntervalSeconds();

	@Meta.AD(
		deflt = "120",
		description = "Added to the session timeout to form the lease. Must be greater than the heartbeat interval plus max clock skew between nodes.",
		name = "Lease grace period (seconds)", required = false
	)
	public int gracePeriodSeconds();

	@Meta.AD(
		deflt = "Administrator",
		description = "Users with any of these regular roles may have concurrent sessions.",
		name = "Exempt role names", required = false
	)
	public String[] exemptRoleNames();

	@Meta.AD(
		deflt = "false",
		description = "If the registry DB is unavailable during login: true = allow login untracked, false = reject.",
		name = "Fail open", required = false
	)
	public boolean failOpen();

}
