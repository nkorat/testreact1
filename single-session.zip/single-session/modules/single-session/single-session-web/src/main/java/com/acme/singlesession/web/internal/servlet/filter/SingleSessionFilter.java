package com.acme.singlesession.web.internal.servlet.filter;

import com.acme.singlesession.web.internal.manager.SingleSessionManager;

import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.servlet.BaseFilter;
import com.liferay.portal.kernel.util.PortalUtil;
import com.liferay.portal.kernel.util.WebKeys;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

/**
 * Runs on every request with an authenticated session and:
 * <ol>
 *   <li>renews the lease (throttled to one DB write per heartbeat interval);</li>
 *   <li>acts as a safety net: if an authenticated session is not the
 *       registered owner and cannot claim ownership, it is rejected.</li>
 * </ol>
 * WebKeys.USER_ID is only put in the session at login, so guests skip this
 * filter at the cost of one session attribute read.
 */
@Component(
	property = {
		"after-filter=Auto Login Filter", "dispatcher=REQUEST",
		"servlet-context-name=",
		"servlet-filter-name=Acme Single Session Filter", "url-pattern=/*"
	},
	service = Filter.class
)
public class SingleSessionFilter extends BaseFilter {

	@Override
	protected Log getLog() {
		return _log;
	}

	@Override
	protected void processFilter(
			HttpServletRequest httpServletRequest,
			HttpServletResponse httpServletResponse, FilterChain filterChain)
		throws Exception {

		if (_singleSessionManager.isEnabled()) {
			HttpSession session = httpServletRequest.getSession(false);

			if (session != null) {
				Long userId = (Long)session.getAttribute(WebKeys.USER_ID);

				if ((userId != null) && (userId > 0) &&
					!_singleSessionManager.verify(
						session, PortalUtil.getCompanyId(httpServletRequest),
						userId)) {

					_singleSessionManager.reject(
						httpServletRequest, httpServletResponse);

					return;
				}
			}
		}

		processFilter(
			SingleSessionFilter.class.getName(), httpServletRequest,
			httpServletResponse, filterChain);
	}

	private static final Log _log = LogFactoryUtil.getLog(
		SingleSessionFilter.class);

	@Reference
	private SingleSessionManager _singleSessionManager;

}
