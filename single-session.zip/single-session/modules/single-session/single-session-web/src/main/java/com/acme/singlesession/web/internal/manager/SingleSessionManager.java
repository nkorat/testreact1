package com.acme.singlesession.web.internal.manager;

import com.acme.singlesession.service.ActiveSessionLocalService;
import com.acme.singlesession.web.configuration.SingleSessionConfiguration;

import com.liferay.portal.configuration.metatype.bnd.util.ConfigurableUtil;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.service.RoleLocalService;
import com.liferay.portal.kernel.util.ArrayUtil;
import com.liferay.portal.kernel.util.PortalUtil;

import java.io.IOException;

import java.util.Date;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.osgi.service.component.annotations.Activate;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Modified;
import org.osgi.service.component.annotations.Reference;

/**
 * Facade over the DB registry. Holds all policy (exemptions, lease math,
 * retries, fail-open/closed) so the login action, filter and session listener
 * stay trivial.
 *
 * Session attributes are a per-session cache so that the DB is touched only
 * at login, once per heartbeat interval, and at session destroy.
 */
@Component(
	configurationPid = "com.acme.singlesession.web.configuration.SingleSessionConfiguration",
	service = SingleSessionManager.class
)
public class SingleSessionManager {

	public enum ClaimResult {

		CLAIMED, EXEMPT, REJECTED, UNTRACKED

	}

	public ClaimResult claim(HttpSession session, long companyId, long userId) {
		if (!_configuration.enabled()) {
			return ClaimResult.UNTRACKED;
		}

		if (_isExempt(session, companyId, userId)) {
			return ClaimResult.EXEMPT;
		}

		String sessionId = _normalize(session.getId());

		Exception lastException = null;

		for (int attempt = 1; attempt <= _MAX_ATTEMPTS; attempt++) {
			Date now = new Date();

			try {
				boolean claimed = _activeSessionLocalService.claim(
					companyId, userId, sessionId, _nodeId, now,
					_getExpirationDate(session, now));

				if (!claimed) {
					if (_log.isInfoEnabled()) {
						_log.info(
							"Rejected concurrent login for user " + userId +
								" (session " + sessionId + ")");
					}

					return ClaimResult.REJECTED;
				}

				session.setAttribute(_ATTR_OWNER_USER_ID, userId);
				session.setAttribute(_ATTR_LAST_HEARTBEAT, now.getTime());
				session.removeAttribute(_ATTR_UNTRACKED_UNTIL);

				return ClaimResult.CLAIMED;
			}
			catch (Exception exception) {

				// Lost a race (duplicate PK / MVCC) or DB failure. The next
				// attempt re-reads the row and resolves the race correctly.

				lastException = exception;

				if (_log.isDebugEnabled()) {
					_log.debug(
						"Claim attempt " + attempt + " failed for user " +
							userId,
						exception);
				}
			}
		}

		if (_configuration.failOpen()) {
			_log.error(
				"Registry unavailable; allowing untracked login for user " +
					userId,
				lastException);

			session.setAttribute(
				_ATTR_UNTRACKED_UNTIL,
				System.currentTimeMillis() + _getHeartbeatIntervalMillis());

			return ClaimResult.UNTRACKED;
		}

		_log.error(
			"Registry unavailable; rejecting login for user " + userId,
			lastException);

		return ClaimResult.REJECTED;
	}

	public boolean isEnabled() {
		return _configuration.enabled();
	}

	public void reject(
			HttpServletRequest httpServletRequest,
			HttpServletResponse httpServletResponse)
		throws IOException {

		HttpSession session = httpServletRequest.getSession(false);

		if (session != null) {
			try {
				session.invalidate();
			}
			catch (IllegalStateException illegalStateException) {

				// Already invalidated

			}
		}

		if (!httpServletResponse.isCommitted()) {
			httpServletResponse.sendRedirect(
				_configuration.rejectedRedirectURL());

			// Commit the 302 now so nothing later in the request (page
			// rendering, error handling) can replace it.

			httpServletResponse.flushBuffer();
		}
	}

	public void release(HttpSession session) {
		Object ownerUserId;

		try {
			ownerUserId = session.getAttribute(_ATTR_OWNER_USER_ID);
		}
		catch (IllegalStateException illegalStateException) {
			return;
		}

		if (!(ownerUserId instanceof Long)) {
			return;
		}

		try {
			_activeSessionLocalService.release(
				(Long)ownerUserId, _normalize(session.getId()));
		}
		catch (Exception exception) {

			// Row will be reclaimable once its lease expires

			_log.error(
				"Unable to release session for user " + ownerUserId,
				exception);
		}
	}

	/**
	 * Called on every authenticated request. Cheap (session attributes only)
	 * except once per heartbeat interval.
	 *
	 * @return {@code false} if this session must be rejected
	 */
	public boolean verify(HttpSession session, long companyId, long userId) {
		if (!_configuration.enabled() ||
			Boolean.TRUE.equals(session.getAttribute(_ATTR_EXEMPT))) {

			return true;
		}

		long nowMillis = System.currentTimeMillis();

		Long untrackedUntil = (Long)session.getAttribute(
			_ATTR_UNTRACKED_UNTIL);

		if ((untrackedUntil != null) && (nowMillis < untrackedUntil)) {
			return true;
		}

		Object ownerUserId = session.getAttribute(_ATTR_OWNER_USER_ID);

		if ((ownerUserId instanceof Long) && ((Long)ownerUserId == userId)) {
			Long lastHeartbeat = (Long)session.getAttribute(
				_ATTR_LAST_HEARTBEAT);

			if ((lastHeartbeat != null) &&
				((nowMillis - lastHeartbeat) < _getHeartbeatIntervalMillis())) {

				return true;
			}

			Date now = new Date(nowMillis);

			try {
				if (_activeSessionLocalService.heartbeat(
						userId, _normalize(session.getId()), now,
						_getExpirationDate(session, now))) {

					session.setAttribute(_ATTR_LAST_HEARTBEAT, nowMillis);

					return true;
				}

				// Ownership lost (row force-released or lease taken over).
				// Fall through and try to re-claim.

			}
			catch (Exception exception) {

				// Transient DB error or MVCC conflict between two parallel
				// requests of this same session: never kick an established
				// owner for that. Retry on a later request.

				if (_log.isWarnEnabled()) {
					_log.warn(
						"Heartbeat failed for user " + userId, exception);
				}

				return true;
			}
		}

		// Session is authenticated but not (or no longer) the owner: e.g.
		// logged in before this module was deployed, or the login-time
		// rejection was bypassed. Enforce now.

		return claim(session, companyId, userId) != ClaimResult.REJECTED;
	}

	@Activate
	@Modified
	protected void activate(Map<String, Object> properties) {
		_configuration = ConfigurableUtil.createConfigurable(
			SingleSessionConfiguration.class, properties);

		_nodeId = PortalUtil.getComputerName();

		if (_configuration.gracePeriodSeconds() <=
				_configuration.heartbeatIntervalSeconds()) {

			_log.warn(
				"gracePeriodSeconds should exceed heartbeatIntervalSeconds, " +
					"otherwise live sessions can be taken over");
		}
	}

	private Date _getExpirationDate(HttpSession session, Date now) {
		int maxInactiveSeconds = session.getMaxInactiveInterval();

		if (maxInactiveSeconds <= 0) {
			maxInactiveSeconds = _DEFAULT_MAX_INACTIVE_SECONDS;
		}

		long leaseMillis =
			(maxInactiveSeconds + (long)_configuration.gracePeriodSeconds()) *
				1000L;

		return new Date(now.getTime() + leaseMillis);
	}

	private long _getHeartbeatIntervalMillis() {
		return _configuration.heartbeatIntervalSeconds() * 1000L;
	}

	private boolean _isExempt(
		HttpSession session, long companyId, long userId) {

		Boolean exempt = (Boolean)session.getAttribute(_ATTR_EXEMPT);

		if (exempt != null) {
			return exempt;
		}

		exempt = false;

		String[] roleNames = _configuration.exemptRoleNames();

		if (ArrayUtil.isNotEmpty(roleNames)) {
			try {
				exempt = _roleLocalService.hasUserRoles(
					userId, companyId, roleNames, true);
			}
			catch (Exception exception) {
				_log.warn(
					"Unable to evaluate exempt roles for user " + userId,
					exception);
			}
		}

		session.setAttribute(_ATTR_EXEMPT, exempt);

		return exempt;
	}

	/**
	 * Strips the Tomcat jvmRoute suffix (e.g. "ABC123.node1" -> "ABC123") so a
	 * replicated session that fails over to another node keeps its ownership.
	 */
	private String _normalize(String sessionId) {
		int index = sessionId.indexOf('.');

		if (index > 0) {
			return sessionId.substring(0, index);
		}

		return sessionId;
	}

	private static final String _ATTR_EXEMPT =
		SingleSessionManager.class.getName() + "#EXEMPT";

	private static final String _ATTR_LAST_HEARTBEAT =
		SingleSessionManager.class.getName() + "#LAST_HEARTBEAT";

	private static final String _ATTR_OWNER_USER_ID =
		SingleSessionManager.class.getName() + "#OWNER_USER_ID";

	private static final String _ATTR_UNTRACKED_UNTIL =
		SingleSessionManager.class.getName() + "#UNTRACKED_UNTIL";

	private static final int _DEFAULT_MAX_INACTIVE_SECONDS = 1800;

	private static final int _MAX_ATTEMPTS = 2;

	private static final Log _log = LogFactoryUtil.getLog(
		SingleSessionManager.class);

	@Reference
	private ActiveSessionLocalService _activeSessionLocalService;

	private volatile SingleSessionConfiguration _configuration;
	private volatile String _nodeId;

	@Reference
	private RoleLocalService _roleLocalService;

}
