package com.acme.singlesession.web.internal.events;

import com.acme.singlesession.web.internal.manager.SingleSessionManager;

import com.liferay.portal.kernel.events.Action;
import com.liferay.portal.kernel.events.ActionException;
import com.liferay.portal.kernel.events.LifecycleAction;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.util.PortalUtil;
import com.liferay.portal.kernel.util.WebKeys;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

/**
 * Fires for every way a Liferay session becomes authenticated (form login and
 * SSO auto-login via SAML/OIDC both end in MainServlet's login, which fires
 * login.events.post). This is the primary enforcement point.
 *
 * On rejection the session is invalidated and a 302 is committed immediately.
 * The rest of this request may still run server-side, but its output cannot
 * reach the browser, and the next request arrives with no authenticated
 * session.
 */
@Component(
	property = "key=login.events.post", service = LifecycleAction.class
)
public class SingleSessionLoginPostAction extends Action {

	@Override
	public void run(
			HttpServletRequest httpServletRequest,
			HttpServletResponse httpServletResponse)
		throws ActionException {

		if (!_singleSessionManager.isEnabled()) {
			return;
		}

		try {
			HttpSession session = httpServletRequest.getSession();

			long userId = _getUserId(httpServletRequest, session);

			if (userId <= 0) {
				return;
			}

			SingleSessionManager.ClaimResult claimResult =
				_singleSessionManager.claim(
					session, PortalUtil.getCompanyId(httpServletRequest),
					userId);

			if (claimResult == SingleSessionManager.ClaimResult.REJECTED) {
				_singleSessionManager.reject(
					httpServletRequest, httpServletResponse);
			}
		}
		catch (Exception exception) {
			_log.error(exception);

			throw new ActionException(exception);
		}
	}

	private long _getUserId(
		HttpServletRequest httpServletRequest, HttpSession session) {

		Long userId = (Long)session.getAttribute(WebKeys.USER_ID);

		if (userId != null) {
			return userId;
		}

		return PortalUtil.getUserId(httpServletRequest);
	}

	private static final Log _log = LogFactoryUtil.getLog(
		SingleSessionLoginPostAction.class);

	@Reference
	private SingleSessionManager _singleSessionManager;

}
