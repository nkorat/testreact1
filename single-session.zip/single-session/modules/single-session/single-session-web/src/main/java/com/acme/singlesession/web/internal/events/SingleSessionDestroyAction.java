package com.acme.singlesession.web.internal.events;

import com.acme.singlesession.web.internal.manager.SingleSessionManager;

import com.liferay.portal.kernel.events.LifecycleAction;
import com.liferay.portal.kernel.events.SessionAction;

import javax.servlet.http.HttpSession;

import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

/**
 * Logout, session timeout and explicit invalidation all end here, which frees
 * the lock right away. A node crash skips this; then the lease expiry in the
 * registry frees the lock instead.
 */
@Component(
	property = "key=servlet.session.destroy.events",
	service = LifecycleAction.class
)
public class SingleSessionDestroyAction extends SessionAction {

	@Override
	public void run(HttpSession session) {
		_singleSessionManager.release(session);
	}

	@Reference
	private SingleSessionManager _singleSessionManager;

}
