package com.acme.singlesession.service.impl;

import com.acme.singlesession.model.ActiveSession;
import com.acme.singlesession.service.base.ActiveSessionLocalServiceBaseImpl;

import com.liferay.portal.aop.AopService;
import com.liferay.portal.kernel.transaction.Propagation;
import com.liferay.portal.kernel.transaction.Transactional;

import java.util.Date;

import org.osgi.service.component.annotations.Component;

/**
 * Registry primitives. Every write runs in its own REQUIRES_NEW transaction so
 * that:
 * <ul>
 *   <li>a constraint violation (concurrent INSERT on the userId PK) or an MVCC
 *       conflict surfaces to the caller as an exception at commit, without
 *       poisoning any outer transaction (important on PostgreSQL);</li>
 *   <li>the caller can simply retry, and the retry re-reads the winner's row.</li>
 * </ul>
 *
 * Run {@code blade gw buildService} after adding/changing methods so the
 * ActiveSessionLocalService interface (and its @Transactional metadata) is
 * regenerated.
 */
@Component(
	property = "model.class.name=com.acme.singlesession.model.ActiveSession",
	service = AopService.class
)
public class ActiveSessionLocalServiceImpl
	extends ActiveSessionLocalServiceBaseImpl {

	/**
	 * Tries to make {@code sessionId} the owner of {@code userId}'s login.
	 *
	 * @return {@code true} if this session now owns the login (new row, same
	 *         session re-claiming, or take-over of an expired lease);
	 *         {@code false} if another, still-live session owns it
	 * @throws RuntimeException if a concurrent claim won the race (duplicate
	 *         PK or MVCC conflict) or the DB failed; callers should retry once
	 */
	@Transactional(
		propagation = Propagation.REQUIRES_NEW, rollbackFor = Exception.class
	)
	public boolean claim(
		long companyId, long userId, String sessionId, String nodeId,
		Date now, Date expirationDate) {

		ActiveSession activeSession =
			activeSessionPersistence.fetchByPrimaryKey(userId);

		if (activeSession == null) {
			activeSession = activeSessionPersistence.create(userId);
		}
		else if (!sessionId.equals(activeSession.getSessionId()) &&
				 !_isExpired(activeSession, now)) {

			return false;
		}

		if (!sessionId.equals(activeSession.getSessionId())) {
			activeSession.setCreateDate(now);
		}

		activeSession.setCompanyId(companyId);
		activeSession.setSessionId(sessionId);
		activeSession.setNodeId(nodeId);
		activeSession.setLastHeartbeatDate(now);
		activeSession.setExpirationDate(expirationDate);

		activeSessionPersistence.update(activeSession);

		return true;
	}

	/**
	 * Extends the lease if {@code sessionId} still owns the row.
	 *
	 * @return {@code false} if the row is gone or owned by another session
	 */
	@Transactional(
		propagation = Propagation.REQUIRES_NEW, rollbackFor = Exception.class
	)
	public boolean heartbeat(
		long userId, String sessionId, Date now, Date expirationDate) {

		ActiveSession activeSession =
			activeSessionPersistence.fetchByPrimaryKey(userId);

		if ((activeSession == null) ||
			!sessionId.equals(activeSession.getSessionId())) {

			return false;
		}

		activeSession.setLastHeartbeatDate(now);
		activeSession.setExpirationDate(expirationDate);

		activeSessionPersistence.update(activeSession);

		return true;
	}

	/**
	 * Deletes the row only if {@code sessionId} owns it, so a destroyed
	 * non-owner session (e.g. a rejected one) can never free someone else's
	 * lock.
	 */
	@Transactional(
		propagation = Propagation.REQUIRES_NEW, rollbackFor = Exception.class
	)
	public boolean release(long userId, String sessionId) {
		ActiveSession activeSession =
			activeSessionPersistence.fetchByPrimaryKey(userId);

		if ((activeSession == null) ||
			!sessionId.equals(activeSession.getSessionId())) {

			return false;
		}

		activeSessionPersistence.remove(activeSession);

		return true;
	}

	/**
	 * Helpdesk/admin unlock, for when the owning browser was closed without
	 * logging out or the owning node crashed before the lease expired.
	 */
	@Transactional(
		propagation = Propagation.REQUIRES_NEW, rollbackFor = Exception.class
	)
	public boolean forceRelease(long userId) {
		ActiveSession activeSession =
			activeSessionPersistence.fetchByPrimaryKey(userId);

		if (activeSession == null) {
			return false;
		}

		activeSessionPersistence.remove(activeSession);

		return true;
	}

	private boolean _isExpired(ActiveSession activeSession, Date now) {
		Date expirationDate = activeSession.getExpirationDate();

		if ((expirationDate == null) || expirationDate.before(now)) {
			return true;
		}

		return false;
	}

}
