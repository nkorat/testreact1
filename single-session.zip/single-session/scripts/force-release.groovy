// Control Panel > Server Administration > Script (Groovy)
// Unlocks a user whose owning browser was closed without logout or whose
// owning node crashed. Their next login will succeed.

import com.acme.singlesession.service.ActiveSessionLocalServiceUtil
import com.liferay.portal.kernel.service.UserLocalServiceUtil

long companyId = com.liferay.portal.kernel.util.PortalUtil.getDefaultCompanyId()
String emailAddress = "jane.doe@example.com"

def user = UserLocalServiceUtil.getUserByEmailAddress(companyId, emailAddress)

def row = ActiveSessionLocalServiceUtil.fetchActiveSession(user.getUserId())
out.println("Current owner: " + (row == null ? "none" :
	row.getSessionId() + " on " + row.getNodeId() + ", lease until " + row.getExpirationDate()))

out.println("Released: " + ActiveSessionLocalServiceUtil.forceRelease(user.getUserId()))
